package com.example.search.service;

import org.springframework.stereotype.Service;

import com.example.search.model.Product;
import com.example.search.repository.ProductRepository;

@Service
public class ProductService {

    private final ProductRepository repository;

    public ProductService(ProductRepository repository) {
        this.repository = repository;
    }

    public Product save(Product product) {
        return repository.save(product);
    }

    public Iterable<Product> findAll() {
        return repository.findAll();
    }
}