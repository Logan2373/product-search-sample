package com.example.search.repository;

import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;
import org.springframework.stereotype.Repository;

import com.example.search.model.Product;

@Repository
public interface ProductRepository
        extends ElasticsearchRepository<Product, String> {
}