package com.example.search.controller;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/products")
public class ProductController {
	@GetMapping("/health")
	public String health() {
		return "UP";
	}
}